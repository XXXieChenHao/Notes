new Waterfall({
  elem: '.J_wrap',  // 元素选择
  column: 5,        // 列数
  gap: 10           // 间隙
}).init();